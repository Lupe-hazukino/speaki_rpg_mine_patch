@echo off
setlocal
set "speakiSource=%~1"
if not defined speakiSource set "speakiSource=%LOCALAPPDATA%\Programs\SpeakiRPG"
where py >nul 2>&1
if errorlevel 1 goto noLauncher
py -3 "%~dp0pc\launcher.py" --install "%speakiSource%"
goto done
:noLauncher
python "%~dp0pc\launcher.py" --install "%speakiSource%"
:done
set "speakiResult=%ERRORLEVEL%"
if errorlevel 1 (
    echo Installation failed. See README.txt.
) else (
    echo Start the game using its desktop shortcut.
)
pause
exit /b %speakiResult%
