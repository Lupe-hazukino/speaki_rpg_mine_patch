﻿スピキクラフトMOD　【SpeakiMod＋】対応版
バージョン 1.3.2-Plus

■ どんなMOD？
スピキクラフトMODは、鉱山の利便性を向上させるパッチです。
鉱山内でのみ動作し、操作方法を変更・改善します。

そのスピキクラフトMODの鉱山機能を、SpeakiMod+ のWindows版で使うためのパッチです。
このZIPに入っているのは、スピキクラフトMODのパッチと導入手順です。

SpeakiMod+を前提MODとして機能するような仕組みです。

■ chrome拡張機能版との違い
・スピキクラフトMODの更新が起動時に自動的に行われます！楽です。
・F9で、通常表示 → 左上のSpeaki MOD +を非表示 → 右上のHUDも非表示 → アイテム欄と一人称の手も非表示 → 通常表示、と切り替えます。

■ 先に用意するもの
・Python 3.10 以上
・Windows 10/11（64ビット、Windows標準の tar.exe が使える環境）

■ 導入と起動
1. ZIPを展開し、初回だけ Install.cmd を実行します。必要なSpeakiMod+ Windows版は、DJTOMATO氏の配布元から自動で取得されます。
2. デスクトップの「スピキクラフトMOD Plus」から起動します。次回以降も同じアイコンを使います。

SpeakiMod+ はDJTOMATO氏が配布するMODです。必要なWindows版は Install.cmd が自動取得します。標準以外の場所にある対応版を再利用する場合は、そのフォルダーを Install.cmd へドラッグできます。
https://github.com/DJTOMATO/SpeakiRPG/releases

■ 自動更新
起動すると、ランチャーがSpeakiMod+ Windows版とスピキクラフトMODの対応する組み合わせを確認します。新しい対応版があれば、準備が完了してから起動先を切り替えます。更新の途中で通信や検証に失敗した場合は前回の版で起動し、次回に再試行します。
鉱山機能だけの更新は、起動時やゲームの再読み込み時に反映されます。ゲームの互換性を確認できない間は鉱山機能を休止し、SpeakiMod+で起動します。
ログイン情報と設定の保存先は %LOCALAPPDATA%\Programs\SpeakiCraft-Plus\profile です。
