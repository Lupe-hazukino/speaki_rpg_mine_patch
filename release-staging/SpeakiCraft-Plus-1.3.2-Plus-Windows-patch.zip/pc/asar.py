"""Read and replace ASAR entries without running Electron or changing other entries."""
import copy
import hashlib
import json
import struct


def decode(data):
    if len(data) < 16:
        raise ValueError('Invalid ASAR header')
    payload, size, pickle_size, length = struct.unpack_from('<IIII', data)
    if payload != 4 or size < 8 or pickle_size + 4 != size or length > size - 8 or 8 + size > len(data):
        raise ValueError('Invalid ASAR sizes')
    return json.loads(data[16:16 + length]), data[8 + size:]


def entry(header, name):
    current = header
    for part in name.split('/'):
        current = current['files'][part]
    if 'files' in current or current.get('unpacked') or 'link' in current:
        raise ValueError('Expected a packed file: ' + name)
    return current


def read(data, name):
    header, body = decode(data)
    item = entry(header, name)
    start, size = int(item['offset']), item['size']
    if start < 0 or size < 0 or start + size > len(body):
        raise ValueError('ASAR entry out of range')
    return body[start:start + size]


def replace(data, name, content):
    header, body = decode(data)
    header = copy.deepcopy(header)
    item = entry(header, name)
    item.update(offset=str(len(body)), size=len(content))
    if 'integrity' in item:
        block_size = item['integrity']['blockSize']
        item['integrity'] = dict(algorithm='SHA256', hash=hashlib.sha256(content).hexdigest(),
                                 blockSize=block_size, blocks=[hashlib.sha256(content[i:i + block_size]).hexdigest()
                                                              for i in range(0, len(content), block_size)])
    encoded = json.dumps(header, ensure_ascii=False, separators=(',', ':')).encode('utf8')
    padding = (-len(encoded)) % 4
    size = 8 + len(encoded) + padding
    return struct.pack('<IIII', 4, size, size - 4, len(encoded)) + encoded + b'\0' * padding + body + content
