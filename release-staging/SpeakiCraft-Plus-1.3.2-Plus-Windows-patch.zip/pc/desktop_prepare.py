"""Build a reviewed desktop app beside the active one. Run from a release kit."""
import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

from launcher import LOADING_FILES, download, extract_kit, file_hash, get_release
from patch_app import create_copy


def prepare(kit, destination, local_source, cache):
    spec = json.loads((kit / 'pc/desktop.json').read_text('utf8'))
    apps = json.loads((kit / 'pc/supported-apps.json').read_text('utf8'))
    app = next(entry for entry in apps if entry['version'] == spec['upstreamVersion'])
    bundle = kit / 'bundle'
    # The first launcher extracted a fixed file list. Complete that upgrade from
    # the same verified ZIP before switching its active generation.
    if not all((kit / name).is_file() for name in LOADING_FILES):
        record = get_release()
        if record['revision'] != spec['revision']:
            raise ValueError('Desktop release changed during update')
        with TemporaryDirectory() as recovery:
            package = Path(recovery) / 'desktop.zip'
            download(record['url'], package, record['bytes'], record['sha256'])
            extract_kit(package, kit, LOADING_FILES)

    def report(message):
        if os.environ.get('SC_REPORT_PROGRESS') == '1':
            print(message, flush=True)

    def build_from(source):
        report('@stage build')
        if file_hash(source / 'resources/app.asar') != app['asarSHA256']:
            raise ValueError('SpeakiMod+ app.asar の検証に失敗しました')
        create_copy(source, destination, bundle, shared_profile=True)

    local_archive = local_source / 'resources/app.asar'
    if (local_source / 'SpeakiRPG.exe').is_file() and local_archive.is_file() and file_hash(local_archive) == app['asarSHA256']:
        build_from(local_source)
        return
    cache.mkdir(parents=True, exist_ok=True)
    payload = cache / (spec['payloadSHA256'] + '.7z')
    with TemporaryDirectory(dir=cache) as temporary:
        work = Path(temporary)
        if not payload.is_file() or file_hash(payload) != spec['payloadSHA256']:
            installer = work / 'upstream.exe'
            url = app['url']
            if not url.startswith('https://github.com/DJTOMATO/SpeakiRPG/releases/download/'):
                raise ValueError('Unknown SpeakiMod+ download source')
            print('SpeakiMod+ Windows ' + app['version'] + ' を取得しています…', flush=True)
            report('@stage upstream')
            download(url, installer, spec['installerBytes'], app['installerSHA256'],
                     lambda fraction: report('@bytes ' + str(fraction)))
            pending = work / 'payload.7z'
            with installer.open('rb') as source, pending.open('wb') as output:
                source.seek(spec['payloadOffset'])
                remaining = spec['payloadBytes']
                while remaining:
                    chunk = source.read(min(remaining, 1024 * 1024))
                    if not chunk:
                        raise ValueError('Incomplete SpeakiMod+ application archive')
                    output.write(chunk)
                    remaining -= len(chunk)
            if file_hash(pending) != spec['payloadSHA256']:
                raise ValueError('SpeakiMod+ アプリの検証に失敗しました')
            os.replace(pending, payload)
        extracted = work / 'windows'
        report('@stage extract')
        extracted.mkdir()
        tar = Path(os.environ['SystemRoot']) / 'System32/tar.exe'
        subprocess.run([str(tar), '-xf', str(payload), '-C', str(extracted)], check=True)
        build_from(extracted)


if __name__ == '__main__':
    prepare(Path(__file__).resolve().parents[1], *(Path(arg) for arg in sys.argv[1:]))

