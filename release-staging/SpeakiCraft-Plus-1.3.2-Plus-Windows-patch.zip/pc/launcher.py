"""Windows entry point for installing and starting the reviewed SpeakiCraft Plus pair."""
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import time
from urllib.request import Request, urlopen
import uuid
from zipfile import ZipFile

CHANNEL = 'https://raw.githubusercontent.com/Lupe-hazukino/speaki_rpg_mine_patch/main/pc/channel/desktop.json'
RELEASE = 'https://github.com/Lupe-hazukino/speaki_rpg_mine_patch/releases/download/'
LOADING_FILES = ('pc/SpeakiLoading.exe', 'pc/media/intro.mp4', 'pc/media/loop.mp4',
                 'pc/media/intro.jpg', 'pc/media/loop.jpg')
FILES = ('pc/launcher.py', 'pc/desktop_prepare.py', 'pc/desktop.json', 'pc/patch_app.py',
         'pc/asar.py', 'pc/supported-apps.json', 'pc/README.txt', 'pc/SpeakiCraft.ico',
         'bundle/build.json', 'bundle/bootstrap.js') + LOADING_FILES
MAX_PACKAGE = 16 * 1024 * 1024
GAME = 'SpeakiCraft-Plus.exe'


def windows_powershell():
    return str(Path(os.environ['SystemRoot']) / 'System32/WindowsPowerShell/v1.0/powershell.exe')


def game_running():
    command = "if (Get-Process -Name 'SpeakiCraft-Plus' -ErrorAction SilentlyContinue) {exit 22}; exit 0"
    status = subprocess.run([windows_powershell(), '-NoProfile', '-NonInteractive', '-Command', command])
    if status.returncode == 22:
        return True
    status.check_returncode()
    return False


def file_hash(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def download(url, output, size, digest, on_progress=None):
    with urlopen(Request(url, headers={'User-Agent': 'SpeakiCraft-Plus'}), timeout=30) as response, output.open('xb') as stream:
        remaining = size
        while remaining:
            chunk = response.read(min(remaining, 1024 * 1024))
            if not chunk:
                raise ValueError('Incomplete download')
            stream.write(chunk)
            remaining -= len(chunk)
            if on_progress:
                on_progress((size - remaining) / size)
        if response.read(1):
            raise ValueError('Unexpected download size')
    if file_hash(output) != digest:
        raise ValueError('Downloaded file checksum mismatch')


def get_release():
    with urlopen(Request(CHANNEL, headers={'Cache-Control': 'no-cache'}), timeout=4) as response:
        raw = response.read(4097)
    if len(raw) > 4096:
        raise ValueError('Invalid desktop channel')
    data = json.loads(raw)
    if (data.get('schema') != 1 or type(data.get('revision')) is not int or data['revision'] < 1
            or type(data.get('bytes')) is not int or not 0 < data['bytes'] <= MAX_PACKAGE
            or not re.fullmatch('[0-9a-f]{64}', data.get('sha256', ''))
            or not re.fullmatch(re.escape(RELEASE) + r'v[A-Za-z0-9_.-]+/SpeakiCraft-Plus-[A-Za-z0-9_.-]+\.zip', data.get('url', ''))):
        raise ValueError('Invalid desktop update record')
    return data


def extract_kit(archive, target, names=FILES):
    with ZipFile(archive) as package:
        if sum(item.file_size for item in package.infolist()) > MAX_PACKAGE:
            raise ValueError('Package exceeds size limit')
        for name in names:
            path = target / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(package.read(name))


def read_json(path):
    return json.loads(path.read_text('utf8'))


def save_json(path, data):
    pending = path.with_suffix('.pending')
    pending.write_text(json.dumps(data, ensure_ascii=False), 'utf8')
    os.replace(pending, path)


def kit_revision(kit):
    revision = read_json(kit / 'pc/desktop.json')['revision']
    if type(revision) is not int or revision < 1:
        raise ValueError('Invalid kit revision')
    return revision


def install_build(root, source, revision, seed=None, release=None, loading=None):
    builds = root / 'builds'
    builds.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(dir=builds) as temporary:
        stage = Path(temporary) / 'candidate'
        stage.mkdir()
        kit = stage / 'kit'
        if release is not None:
            package = stage / 'release.zip'
            if loading:
                loading.phase('package')
            download(release['url'], package, release['bytes'], release['sha256'],
                     loading.transfer if loading else None)
            extract_kit(package, kit)
            package.unlink()
        else:
            for name in FILES:
                (kit / name).parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(seed / name, kit / name)
        if kit_revision(kit) != revision:
            raise ValueError('Desktop revision mismatch')
        command = [sys.executable, str(kit / 'pc/desktop_prepare.py'), str(stage / 'game'), str(source), str(root / 'cache')]
        if loading:
            loading.phase('prepare')
            with subprocess.Popen(command, stdout=subprocess.PIPE, text=True, encoding='utf8', errors='replace',
                                  env=dict(os.environ, SC_REPORT_PROGRESS='1', PYTHONIOENCODING='utf8')) as child:
                for line in child.stdout:
                    fields = line.rstrip().split()
                    if len(fields) == 2 and fields[0] == '@stage' and fields[1] in ('upstream', 'extract', 'build'):
                        loading.phase(fields[1])
                    elif len(fields) == 2 and fields[0] == '@bytes':
                        loading.transfer(float(fields[1]))
                    else:
                        print(line, end='')
                if child.wait():
                    raise subprocess.CalledProcessError(child.returncode, command)
        else:
            subprocess.run(command, check=True)
        if not (stage / 'game' / GAME).is_file():
            raise ValueError('Incomplete application')
        generation = uuid.uuid4().hex
        os.rename(stage, builds / generation)
    state = dict(revision=revision, generation=generation, source=str(source))
    state_path = root / 'active.json'
    previous = read_json(state_path) if state_path.exists() else {}
    if previous:
        state['previous'] = previous['generation']
    save_json(state_path, state)
    obsolete = previous.get('previous', '')
    if re.fullmatch('[0-9a-f]{32}', obsolete) and obsolete not in (generation, state.get('previous')):
        old = builds / obsolete
        if old.resolve() == old and (old / 'game/compatibility-build.json').is_file():
            try:
                shutil.rmtree(old)
            except OSError as error:
                print('以前のアプリを整理できませんでした。', error)
    return state


def select_build(root, source, seed=None, loading=None):
    state_path = root / 'active.json'
    current = read_json(state_path) if state_path.exists() else None
    current_revision = current['revision'] if current else 0
    if not current and not seed:
        raise ValueError('初回は Install.cmd を実行してください。')
    source = source or Path(current['source'])
    seed_revision = kit_revision(seed) if seed else 0
    if loading:
        loading.phase('check')
    try:
        release = get_release()
        if release['revision'] > max(current_revision, seed_revision):
            print('対応版を準備しています…', flush=True)
            return install_build(root, source, release['revision'], release=release, loading=loading)
    except Exception as error:
        print('更新を取得できませんでした。次回の起動時に再確認します。', error, flush=True)
    if seed_revision > current_revision:
        try:
            return install_build(root, source, seed_revision, seed=seed, loading=loading)
        except Exception:
            if not current:
                raise
            print('同梱版を準備できなかったため、前回の版を使用します。', flush=True)
    if not current:
        raise ValueError('初回は Install.cmd を実行してください。')
    return current


@contextmanager
def launch_lock(root):
    import msvcrt
    with (root / 'launcher.lock').open('a+b') as lock:
        lock.seek(0)
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        try:
            yield
        finally:
            lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)


def shortcut(root, desktop=None):
    values = dict(os.environ, SC_ROOT=str(root), SC_PYTHON=sys.executable,
                  SC_NAME='スピキクラフトMOD Plus.lnk', SC_DESKTOP=str(desktop or ''))
    script = """
$ErrorActionPreference = 'Stop'
$ws = New-Object -ComObject WScript.Shell
$d = $env:SC_DESKTOP
if (-not $d) { $d = $ws.SpecialFolders.Item('Desktop') }
$s = $ws.CreateShortcut((Join-Path $d $env:SC_NAME))
$s.TargetPath = $env:SC_PYTHON
$s.Arguments = '"' + (Join-Path $env:SC_ROOT 'launcher.py') + '"'
$s.WorkingDirectory = $env:SC_ROOT
$s.WindowStyle = 7
$s.IconLocation = (Join-Path $env:SC_ROOT 'SpeakiCraft.ico') + ',0'
$s.Save()
"""
    subprocess.run([windows_powershell(), '-NoProfile', '-NonInteractive', '-Command', script], env=values, check=True)


class LoadingScreen:
    # Stage ranges leave space for a desktop update until the channel check finishes.
    stages = {
        'start': (0, 10, 0.7, 'ランチャーを起動しています'),
        'check': (10, 34, 1.5, 'アップデートを確認しています'),
        'package': (34, 49, 3, '対応版をダウンロードしています'),
        'prepare': (49, 53, 1, '更新ファイルを確認しています'),
        'upstream': (53, 78, 20, 'SpeakiMod+をダウンロードしています'),
        'extract': (78, 90, 5, 'アプリを展開しています'),
        'build': (90, 96, 3, '更新を適用しています'),
        'game': (96, 99, 2, 'ゲームを起動しています'),
    }

    def __init__(self, root):
        self.history_path = root / 'loading-times.json'
        self.history = {}
        self.player = None
        self.current = None
        try:
            saved = read_json(self.history_path) if self.history_path.exists() else {}
            self.history = {name: value for name, value in saved.items() if name in self.stages and
                            isinstance(value, (int, float)) and 0 < value < 3600}
            generation = read_json(root / 'active.json')['generation']
            if not re.fullmatch('[a-f0-9]{32}', generation):
                return
            executable = root / 'builds' / generation / 'kit/pc/SpeakiLoading.exe'
            self.player = subprocess.Popen([str(executable)],
                                           stdin=subprocess.PIPE, text=True, encoding='utf8')
        except (OSError, ValueError, KeyError, AttributeError):
            pass
        self.phase('start')

    def send(self, message):
        if self.player and not self.player.stdin.closed:
            try:
                self.player.stdin.write(message + '\n')
                self.player.stdin.flush()
            except (OSError, ValueError):
                pass

    def budget(self, name):
        return self.history.get(name, self.stages[name][2])

    def phase(self, name):
        now = time.monotonic()
        if self.current:
            duration = max(0.1, now - self.started)
            self.history[self.current] = (self.budget(self.current) + duration) / 2
        self.current = name
        self.started = now
        self.last_sample = 0
        self.transfer(-1)

    def transfer(self, fraction):
        now = time.monotonic()
        if 0 < fraction < 1 and now - self.last_sample < 0.15:
            return
        self.last_sample = now
        low, high, _, label = self.stages[self.current]
        tail = {'start': ('check', 'game'), 'check': ('game',), 'package': ('prepare', 'build', 'game'),
                'prepare': ('build', 'game'), 'upstream': ('extract', 'build', 'game'),
                'extract': ('build', 'game'), 'build': ('game',), 'game': ()}
        later = sum(self.budget(name) for name in tail[self.current])
        seconds = self.budget(self.current)
        if fraction > 0:
            seconds = (now - self.started) * (1 - fraction) / fraction
        self.send(f'progress\t{low}\t{high}\t{seconds:.3f}\t{later:.3f}\t{fraction:.5f}\t{label}')

    def handoff(self, pid):
        if self.player and self.player.poll() is None:
            self.send(f'game\t{pid}')
            try:
                save_json(self.history_path, self.history)
            except OSError:
                pass

    def close(self):
        if self.player:
            try:
                self.player.stdin.close()
            except OSError:
                pass


def main():
    root = Path(os.environ['LOCALAPPDATA']) / 'Programs/SpeakiCraft-Plus-Launcher'
    root.mkdir(parents=True, exist_ok=True)
    installing = sys.argv[1:2] == ['--install']
    with launch_lock(root):
        loading = None if installing else LoadingScreen(root)
        try:
            start(root, installing, loading)
        finally:
            if loading:
                loading.close()


def start(root, installing, loading):
    if not installing and game_running():
        return
    source = Path(sys.argv[2]).resolve() if installing else None
    seed = Path(__file__).resolve().parents[1] if installing else None
    if not installing and not (root / 'active.json').is_file():
        raise ValueError('初回は Install.cmd を実行してください。')
    state = select_build(root, source, seed, loading)
    if not re.fullmatch('[a-f0-9]{32}', state['generation']):
        raise ValueError('Invalid installation directory')
    build = root / 'builds' / state['generation']
    for name in ['launcher.py', 'SpeakiCraft.ico']:
        origin = build / 'kit/pc' / name
        target = root / name
        if not target.is_file() or file_hash(target) != file_hash(origin):
            pending = target.with_suffix('.new')
            shutil.copyfile(origin, pending)
            os.replace(pending, target)
    if installing:
        shortcut(root)
        print('デスクトップに「スピキクラフトMOD Plus」を作成しました。')
    else:
        loading.phase('game')
        (root.parent / 'SpeakiCraft-Plus/profile').mkdir(parents=True, exist_ok=True)
        game = subprocess.Popen([str(build / 'game' / GAME)], cwd=build / 'game')
        loading.handoff(game.pid)


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        message = '起動の準備ができませんでした。\n' + str(error)
        if sys.argv[1:2] != ['--install']:
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, message, 'スピキクラフトMOD Plus', 0x30)
        sys.exit(message)

