"""Create a separate, reversible PC test app. Never patch the installed app in place."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import uuid
import asar

ROOT = Path(__file__).resolve().parents[1]
MARKER = '// Speaki mining PC compatibility bridge v1'
FETCH_LINE = 'let code = await (await fetch(src)).text();'
PROFILE_LINE = "const path = require('path');"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def patch_injector(original, bootstrap):
    if original.count(FETCH_LINE) != 1 or MARKER in original:
        raise ValueError('Unknown injector structure or already patched')
    hooked = original.replace(FETCH_LINE, FETCH_LINE + '\n\tcode = await prepareMiningForPlus(code, src);')
    # Same page, same game boot owner. The runtime never starts the game itself.
    return MARKER + '\n(() => {\nif(globalThis.__SPEAKI_MINING_INJECTOR_STARTED__)return;\n' + \
        'globalThis.__SPEAKI_MINING_INJECTOR_STARTED__=true;\n' + bootstrap + '\n' + hooked + '\n})();\n'


def patch_main(original, profile='test-profile', shared_profile=False):
    if original.count(PROFILE_LINE) != 1:
        raise ValueError('Unknown main process structure')
    location = ("path.join(process.env.LOCALAPPDATA, 'Programs', 'SpeakiCraft-Plus', 'profile')"
                if shared_profile else f"path.join(path.dirname(process.execPath), '{profile}')")
    return original.replace(PROFILE_LINE, PROFILE_LINE + "\n// Keep the mining app profile separate.\n"
                            f"app.setPath('userData', {location});\n")


def prepare_archive(original, bundle, shared_profile=False):
    supported = json.loads((ROOT / 'pc/supported-apps.json').read_text('utf8'))
    info = json.loads((bundle / 'build.json').read_text('utf8'))
    package = json.loads(asar.read(original, 'package.json'))
    if package.get('name') != 'SpeakiRPG' or not re.fullmatch(r'\d+\.\d+\.\d+', package.get('version', '')):
        raise ValueError('Unexpected app package')
    original_digest = sha(original)
    exact = any(original_digest == item['asarSHA256'] and package['version'] == item['version'] for item in supported)
    # A new desktop package can reuse the same hook code. Compare the complete
    # scripts we depend on rather than treating every package hash as a new API.
    same_hooks = info['channelURL'] and any(
        item.get('hookSHA256') and all(sha(asar.read(original, name)) == digest
                                     for name, digest in item['hookSHA256'].items())
        for item in supported)
    if not (exact or same_hooks):
        raise ValueError('This SpeakiMod+ Windows build changes the integration files. A compatible patch is required.')
    profile = 'profile' if info['channelURL'] else 'test-profile'
    injector = patch_injector(asar.read(original, 'injector.js').decode('utf8'), (bundle / 'bootstrap.js').read_text('utf8'))
    patched = asar.replace(original, 'injector.js', injector.encode('utf8'))
    patched = asar.replace(patched, 'main.js', patch_main(asar.read(original, 'main.js').decode('utf8'), profile, shared_profile).encode('utf8'))
    # Verify every original file; only these two entries may change.
    header, _ = asar.decode(original)
    def verify(files, prefix=''):
        for name, item in files.items():
            key = prefix + name
            if 'files' in item:
                verify(item['files'], key + '/')
            elif not item.get('unpacked') and 'link' not in item and key not in {'injector.js', 'main.js'}:
                if asar.read(patched, key) != asar.read(original, key):
                    raise ValueError('Unrelated ASAR entry changed: ' + key)
    verify(header['files'])
    info.update(originalAsarSHA256=original_digest, patchedAsarSHA256=sha(patched),
                originalAppVersion=package['version'], isolatedProfile=profile, modifiedEntries=['injector.js', 'main.js'])
    return patched, info


def create_copy(source, destination, bundle=None, allow_update=False, shared_profile=False):
    destination = Path(destination).absolute()
    if destination.exists() and destination != destination.resolve():
        raise ValueError('Choose a destination that is not redirected')
    source, destination = Path(source).resolve(), destination.resolve()
    bundle = Path(bundle or ROOT / 'dist/speakimod-plus').resolve()
    if source == destination or source in destination.parents or destination in source.parents:
        raise ValueError('Choose a new destination outside the source app directory')
    original = (source / 'resources/app.asar').read_bytes()
    patched, info = prepare_archive(original, bundle, shared_profile)
    updating = destination.exists()
    if updating:
        if not allow_update or not info['channelURL'] or not destination.is_dir():
            raise ValueError('Choose a new destination, or update an existing SpeakiCraft Plus installation')
        previous = json.loads((destination / 'compatibility-build.json').read_text('utf8'))
        if (previous.get('isolatedProfile') != 'profile' or not previous.get('channelURL') or
                sha((destination / 'resources/app.asar').read_bytes()) != previous.get('patchedAsarSHA256')):
            raise ValueError('The destination is not an intact SpeakiCraft Plus installation')
        check_closed('SpeakiCraft-Plus.exe')
    destination.parent.mkdir(parents=True, exist_ok=True)
    staging = destination.parent / (destination.name + '.staging-' + uuid.uuid4().hex)
    try:
        shutil.copytree(source, staging, ignore=shutil.ignore_patterns('Uninstall*.exe', 'test-profile', 'profile'))
        (staging / 'resources/app.asar.original').write_bytes(original)
        (staging / 'resources/app.asar').write_bytes(patched)
        release = bool(info['channelURL'])
        executable = 'SpeakiCraft-Plus.exe' if release else 'SpeakiCraft-Plus-Test.exe'
        launcher = 'Start-SpeakiCraft-Plus.cmd' if release else 'Start-Test.cmd'
        (staging / 'SpeakiRPG.exe').rename(staging / executable)
        (staging / 'compatibility-build.json').write_text(json.dumps(info, ensure_ascii=False, indent=2) + '\n', 'utf8')
        (staging / launcher).write_bytes(f'@echo off\r\ncd /d "%~dp0"\r\nstart "" "%~dp0{executable}"\r\n'.encode('ascii'))
        instructions = 'README.txt' if release else 'TEST-PLAY.md'
        shutil.copyfile(ROOT / 'pc' / instructions, staging / instructions)
        if updating:
            check_closed(executable)
            replace_copy(staging, destination)
        else:
            os.rename(staging, destination)
    except Exception:
        # Keep staging artifacts for diagnosis; never recursively remove a computed path.
        raise
    print(json.dumps(dict(destination=str(destination), version=info['version'], originalUnchanged=True,
                          isolatedProfile=True, channelURL=info['channelURL']), ensure_ascii=False))
    return destination


def check_closed(executable):
    if os.name == 'nt':
        processes = subprocess.check_output(['tasklist', '/FI', f'IMAGENAME eq {executable}', '/FO', 'CSV', '/NH'],
                                            text=True, errors='replace', creationflags=subprocess.CREATE_NO_WINDOW)
        if f'"{executable.lower()}"' in processes.lower():
            raise ValueError(f'Close {executable} before updating it')


def replace_copy(staging, destination):
    backup = destination.with_name(destination.name + '.previous-' + uuid.uuid4().hex)
    os.rename(destination, backup)
    profile = backup / 'profile'
    moved_profile = False
    try:
        if profile.exists():
            os.rename(profile, staging / 'profile')
            moved_profile = True
        os.rename(staging, destination)
    except OSError:
        if moved_profile:
            os.rename(staging / 'profile', profile)
        os.rename(backup, destination)
        raise
    print(f'Previous application backup: {backup}')


def refresh_copy(destination, bundle=None):
    destination = Path(destination).resolve()
    bundle = Path(bundle or ROOT / 'dist/speakimod-plus').resolve()
    previous = json.loads((destination / 'compatibility-build.json').read_text('utf8'))
    target = destination / 'resources/app.asar'
    if sha(target.read_bytes()) != previous['patchedAsarSHA256']:
        raise ValueError('Test app has changed; refusing to overwrite it')
    if os.name == 'nt':
        processes = subprocess.check_output(['tasklist', '/FI', 'IMAGENAME eq SpeakiCraft-Plus-Test.exe', '/FO', 'CSV', '/NH'],
                                            text=True, errors='replace', creationflags=subprocess.CREATE_NO_WINDOW)
        if '"speakicraft-plus-test.exe"' in processes.lower():
            raise ValueError('Close the running test app before refreshing it')
    original = (destination / 'resources/app.asar.original').read_bytes()
    if sha(original) != previous['originalAsarSHA256']:
        raise ValueError('Original ASAR backup has changed')
    patched, info = prepare_archive(original, bundle)
    backup = target.with_name('app.asar.before-' + previous['version'])
    if backup.exists():
        raise ValueError('A backup for this version already exists')
    shutil.copyfile(target, backup)
    pending = target.with_name('app.asar.pending')
    with pending.open('xb') as output:
        output.write(patched)
    os.replace(pending, target)
    (destination / 'compatibility-build.json').write_text(json.dumps(info, ensure_ascii=False, indent=2) + '\n', 'utf8')
    shutil.copyfile(ROOT / 'pc/TEST-PLAY.md', destination / 'TEST-PLAY.md')
    print(json.dumps(dict(destination=str(destination), version=info['version'], profilePreserved=True,
                          previousAsarBackup=str(backup)), ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source')
    parser.add_argument('--output')
    parser.add_argument('--refresh')
    parser.add_argument('--bundle', type=Path)
    parser.add_argument('--update-existing', action='store_true')
    args = parser.parse_args()
    if args.refresh:
        if args.source or args.output:
            parser.error('--refresh cannot be combined with --source or --output')
        if args.bundle:
            parser.error('--refresh uses the local test bundle only')
        refresh_copy(args.refresh)
    elif args.source and args.output:
        create_copy(args.source, args.output, args.bundle, args.update_existing)
    else:
        parser.error('Specify --source and --output, or --refresh')
